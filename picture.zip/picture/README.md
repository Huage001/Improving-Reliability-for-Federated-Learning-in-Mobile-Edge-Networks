# Improving-Reliability-for-Federated-Learning-in-Mobile-Edge-Networks

* Figure 1: our main graph: average error rate - number of devices
* Figure 2: best error rate performance upon different error rates and normal distribution
* Figure 3: time used
* Figure 4 & Figure 5: average error rate performance upon different device error rates and normal distribution
* Figure 6: average error rate performance upon different distributions. Note that the variances of normal distribution are different
* Figure 7: best error rate performance upon different distributions
* Figure 8: average error rate performance upon different distributions
* Figure 9: average error rate performance upon different device error rates and F distribution
* Figure 10: best error rate performance upon different device error rates, F distribution, and less devices
* Figure 11: best error rate performance upon different device error rates, normal distribution, and less devices
* Figure 12 & Figure 13: best error rate performance upon different distributions
* Figure 14: best error rate performance upon different distributions in device error rate but fix data distribution
* Figure 15: best error rate performance upon different distributions in data but fix device error rate distribution
* Figure 16: another our main graph: average error rate - number of devices