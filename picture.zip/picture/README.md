# Improving-Reliability-for-Federated-Learning-in-Mobile-Edge-Networks

| Figure | device error rate         | transmit error rate | data ratio |
| ------ | ------------------------- | ------------------- | ---------- |
| 1      | 0-0.1 normal distribution | original scale/1000 | 0.5        |
| 2      | 0-0.1 normal distribution | original scale      | 0.5        |
| 3      | 0-0.2 normal distribution | original scale/1000 | 0.5        |
| 4      | 0-0.2 normal distribution | original scale      | 0.5        |
| 5      | 0-0.2 normal distribution | original scale      | 0.8        |
| 6      | 0-0.2 normal distribution | original scale      | 0.9        |
| 7      | 0-0.2 normal distribution | original scale      | 0.3        |
| 8      | 0-0.2 normal distribution | original scale      | 0.3        |

